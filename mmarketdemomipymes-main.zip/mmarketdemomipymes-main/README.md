# mmarketdemomipymes
Demo minimarket para MIPYMES
Se tiene las siguientes características:
- Utiliza JavaEE
- IDE Eclipse
- Wildfly
- Postgresql


